package com.example.manabie_interview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
