import 'dart:ffi';

class TotoEntity {
  String title;
  Bool state;
  TotoEntity({
    required this.title,
    required this.state,
  });
}
